package com.gesturex.control

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/** Android requires explicit camera AND Accessibility consent. No in-app controls after setup. */
class MainActivity : Activity() {
    private val message by lazy { TextView(this).apply { textSize = 19f; setPadding(45, 100, 45, 45) } }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(message)
        proceed()
    }
    private fun enabled(): Boolean = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.split(':')?.any { it.contains("com.gesturex.control/.GestureAccessibilityService", true) || it.contains("com.gesturex.control/com.gesturex.control.GestureAccessibilityService", true) } == true
    private fun proceed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            message.text = "GestureX needs the front camera to recognize hand gestures. Please grant camera access."
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 7)
            return
        }
        if (!enabled()) {
            message.text = "One-time Android setup: enable GestureX AI under Accessibility → Installed apps, then return here. Android requires this permission to control other apps."
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        message.text = "GestureX is starting. You can leave this screen. A permanent notification lets you stop camera tracking."
        ContextCompat.startForegroundService(this, Intent(this, GestureCameraService::class.java))
        message.postDelayed({ finish() }, 1800)
    }
    override fun onResume() { super.onResume(); if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED && enabled()) proceed() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if (requestCode==7 && grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) proceed() }
}
