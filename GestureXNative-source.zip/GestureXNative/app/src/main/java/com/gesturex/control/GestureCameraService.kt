package com.gesturex.control

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import java.util.concurrent.Executors

/** Keeps front-camera recognition running in a visible foreground service. */
class GestureCameraService : LifecycleService() {
    private val executor = Executors.newSingleThreadExecutor()
    private var recognizer: GestureRecognizer? = null
    private var lastAction = 0L
    private var lastFrame = 0L
    private var candidate = ""
    private var consecutive = 0
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("gesturex", "GestureX camera tracking", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, GestureCameraService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification: Notification = NotificationCompat.Builder(this,"gesturex")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("GestureX AI · Camera active")
            .setContentText("Hand gestures are controlling your phone")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel,"Stop",stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(23,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        else startForeground(23,notification)
        try {
            val options = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("gesture_recognizer.task").build())
                .setRunningMode(RunningMode.VIDEO)
                .setMinHandDetectionConfidence(0.65f)
                .build()
            recognizer = GestureRecognizer.createFromOptions(this,options)
            startCamera()
        } catch (e: Exception) { stopSelf() }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if(intent?.action=="STOP") { stopSelf(); return START_NOT_STICKY }
        return super.onStartCommand(intent,flags,startId)
    }
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { frame -> process(frame) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA,analysis)
        },ContextCompat.getMainExecutor(this))
    }
    private fun process(frame: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if(now-lastFrame<150) return
            lastFrame=now
            val plane=frame.planes[0]
            // Convert YUV_420_888 to ARGB without assuming contiguous chroma planes.
            val w=frame.width; val h=frame.height
            val pixels=IntArray(w*h)
            val y=frame.planes[0]; val u=frame.planes[1]; val v=frame.planes[2]
            val yb=y.buffer; val ub=u.buffer; val vb=v.buffer
            for(row in 0 until h) for(col in 0 until w) {
                val yy=yb.get(row*y.rowStride+col*y.pixelStride).toInt() and 255
                val uu=(ub.get((row/2)*u.rowStride+(col/2)*u.pixelStride).toInt() and 255)-128
                val vv=(vb.get((row/2)*v.rowStride+(col/2)*v.pixelStride).toInt() and 255)-128
                val r=(yy+1.402*vv).toInt().coerceIn(0,255)
                val g=(yy-0.344136*uu-0.714136*vv).toInt().coerceIn(0,255)
                val b=(yy+1.772*uu).toInt().coerceIn(0,255)
                pixels[row*w+col]=(255 shl 24) or (r shl 16) or (g shl 8) or b
            }
            val original=Bitmap.createBitmap(pixels,w,h,Bitmap.Config.ARGB_8888)
            val rotated=Bitmap.createBitmap(original,0,0,w,h,Matrix().apply { postRotate(frame.imageInfo.rotationDegrees.toFloat()); postScale(-1f,1f) },true)
            val result=recognizer?.recognizeForVideo(BitmapImageBuilder(rotated).build(),now)
            if(result!=null) handle(result,now)
            original.recycle();rotated.recycle()
        } catch (_: Exception) { } finally { frame.close() }
    }
    private fun handle(result: GestureRecognizerResult, now: Long) {
        val category=result.gestures().firstOrNull()?.firstOrNull() ?: return
        val name=category.categoryName()
        if(category.score()<0.75f || name=="None") { consecutive=0;candidate="";return }
        if(candidate==name) consecutive++ else { candidate=name;consecutive=1 }
        if(consecutive>=3 && now-lastAction>1800) {
            lastAction=now;consecutive=0
            ContextCompat.getMainExecutor(this).execute { GestureAccessibilityService.instance?.execute(name) }
        }
    }
    override fun onDestroy() { recognizer?.close();executor.shutdown();super.onDestroy() }
}
