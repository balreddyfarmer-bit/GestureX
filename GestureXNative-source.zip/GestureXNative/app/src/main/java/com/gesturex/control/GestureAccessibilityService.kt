package com.gesturex.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GestureAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: GestureAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }
    fun execute(gesture: String) {
        when(gesture) {
            "Open_Palm" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "Closed_Fist" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "Thumb_Up" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "Victory" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "Pointing_Up" -> swipe(true)
            "ILoveYou" -> swipe(false)
        }
    }
    private fun swipe(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * .5f
        val start = dm.heightPixels * (if (down) .75f else .3f)
        val end = dm.heightPixels * (if (down) .3f else .75f)
        val path = Path().apply { moveTo(x,start); lineTo(x,end) }
        val stroke = GestureDescription.StrokeDescription(path,0,400)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),null,null)
    }
}
