# GestureX AI — Native Android prototype

This is **Android Studio source code**, not an APK. It has not been compiled or device-tested in this environment.

## Behavior

- First launch: Android camera permission request, followed by the mandatory Android Accessibility Settings screen.
- After setup: front camera runs in a foreground service with a persistent notification and a Stop action; no on-screen buttons or dashboard are needed.
- Gestures: open palm → Home; closed fist → Back; thumbs up → notifications; victory sign → recent apps; pointing up → scroll down; I Love You sign → scroll up.
- Three consecutive detections and a 1.8-second cooldown reduce accidental triggers.
- Camera frames are processed locally; no server upload is implemented.

## Build

1. Open this directory in Android Studio (recent version with Android SDK 35).
2. Sync Gradle while connected to the internet. The build downloads the official MediaPipe gesture recognition model into app assets, and downloads Android dependencies.
3. Build > Build APK(s). Install the APK on your Android phone.
4. Open GestureX AI once, grant camera access, enable GestureX AI in Android Accessibility Settings, and return to the app.
5. Keep the camera tracking notification active. Use its **Stop** action to turn tracking off.

## Android constraints and limitations

- Android does **not** allow an app to control the entire phone with camera permission alone. Accessibility must be enabled manually, and certain protected screens and actions are restricted.
- Modern Android limits when camera foreground services can be started. The service is started while the app is visible; the OS may stop it for battery or privacy reasons.
- The camera privacy indicator and foreground notification are intentionally visible.
- This is an experimental, untested prototype. Camera frames are converted on the CPU and can consume significant battery. Not guaranteed to work on every device.
- Facial expressions and voice control are **not** implemented in this version; this build targets the user's latest request for camera hand gestures without an ongoing app UI.
